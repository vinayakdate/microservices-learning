package com.appsdeveloperblog.ws.api.albums;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlbumsApplicationTests {

	@Test
	void contextLoads() {
	}

}
